
-- -----------------------------------------------------
-- Table `linuxdevice_DEVICE`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS linuxdevice_DEVICE (
  linuxdevice_DEVICE_ID VARCHAR(45) NOT NULL ,
  DEVICE_NAME VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (linuxdevice_DEVICE_ID) );

