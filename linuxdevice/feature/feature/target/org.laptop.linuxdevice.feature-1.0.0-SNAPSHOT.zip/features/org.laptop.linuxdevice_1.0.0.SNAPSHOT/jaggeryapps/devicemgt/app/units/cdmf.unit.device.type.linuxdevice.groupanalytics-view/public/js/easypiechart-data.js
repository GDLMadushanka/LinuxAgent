$(function() {
    $('#easypiechart-teal').easyPieChart({

        scaleColor: false,
        lineWidth:10,
        barColor: '#1ebfae'
    });
});

$(function() {
    $('#easypiechart-orange').easyPieChart({
        scaleColor: false,
        lineWidth:10,
        barColor: '#ffb53e'
    });
});

$(function() {
    $('#easypiechart-red').easyPieChart({
        scaleColor: false,
        lineWidth:10,
        barColor: '#f9243f'
    });
});

$(function() {
   $('#easypiechart-blue').easyPieChart({
       scaleColor: false,
       lineWidth:10,
       barColor: '#30a5ff'
   });
});


